def print_book_title():
    print("으뜸 파이썬")

def print_book_publisher():
    print("생능 출판사")

for _ in range(3):
    print_book_title()

for _ in range(5):
    print_book_publisher()