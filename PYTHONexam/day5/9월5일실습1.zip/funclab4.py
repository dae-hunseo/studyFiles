def print_triangle1(n):
    if n<1 or n>10:
        return
    else:
        i=0
        for i in range(0,n):
            print('*'*(i+1))

num = int(input("1부터 10사이를 입력하시오:"))
print_triangle1(num)