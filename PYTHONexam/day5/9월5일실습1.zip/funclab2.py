def print_book_title():
    return "으뜸 파이썬"

def print_book_publisher():
    print("생능 출판사")

name = print_book_title()

for _ in range(2):
    print(name)

print_book_publisher()