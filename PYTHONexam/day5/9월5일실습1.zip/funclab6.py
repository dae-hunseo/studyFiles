import random


def differtwovalue(n1, n2):
    if n1<n2:
        return n2-n1
    elif n1>n2:
        return n1-n2
    else:
        return 0

for _ in range(5):
    num1 = random.randint(1, 30)
    num2 = random.randint(1, 30)
    print("X와 Y의 차는", differtwovalue(num1, num2), "입니다")