def expr(operand1, operator, operand2):
    if operator == '+':
        result = operand1+operand2
        print("연산결과:", result)
    elif operator == '-':
        result = operand1 - operand2
        print("연산결과:",result)
    elif operator == '*':
        result = operand1 * operand2
        print("연산결과:",result)
    elif operator == '/':
        result = operand1 / operand2
        print("연산결과:",result)
    else:
        print("수행 불가")


str = input("수식을 입력하시오(띄어쓰기 필수):")
str_list = str.split()
expr(int(str_list[0]),str_list[1],int(str_list[2]))

# num1 = int(input("첫번째 피연산자:"))
# op = input("연산자:")
# num2 = int(input("두번째 피연산자:"))
#expr(num1, op, num2)