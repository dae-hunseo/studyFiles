try:
    f = open("yesterday.txt", "rt", encoding="UTF-8") #fileiotest4.py 참고
except FileNotFoundError:
    print('파일을 읽을 수 없어요')
else:
    text = f.read().lower()
    c = text.count('yesterday')
    print("Number of a Word 'Yesterday': {}".format(c))