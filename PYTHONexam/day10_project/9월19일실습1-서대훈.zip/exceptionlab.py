while True:
    try:
        num = int(input('숫자를 입력하시오:'))
    except ValueError:
        print('숫자만 입력해주세요~~~')
        continue
    else:
        break

s = 0
for i in range(1, num+1):
    s += i

print(f"1부터 {i}까지의 합은 {s}입니다")