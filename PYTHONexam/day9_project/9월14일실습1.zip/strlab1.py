def myemail_info(email):
    if '@' not in email:
        return None
    else:
        tup = tuple(email.split('@'))
        return tup


print(myemail_info('0420sdh@naver.com'))