import random

list = [random.randint(0,100) for i in range(10)]

dic = {i+1:"pass"if list[i]>=60 else "nopass" for i in range(10)}

print(dic)