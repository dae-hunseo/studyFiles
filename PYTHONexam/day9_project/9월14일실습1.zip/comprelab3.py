def mycompredict(**kwargs):
    dic = {}
    if len(kwargs) == 0:
        return dic
    else:
        dic = {'my'+k:v for k, v in kwargs.items()}
        return dic

print(mycompredict(name='서대훈', address='대구'))