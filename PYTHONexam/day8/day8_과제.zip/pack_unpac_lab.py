listv = ['p', 'y', 't','h', 'o', 'n']
v1, v2, v3, v4, v5, v6 = listv

print(v1)
print(v2)
print(v3)
print(v4)
print(v5)
print(v6)

print(*listv)
print(listv)