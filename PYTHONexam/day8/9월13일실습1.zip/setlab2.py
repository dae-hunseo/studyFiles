import random
set = set()
while len(set)<=6:
    set.add(random.randint(1, 45))
print(set)