import math
import time

print(dir(math))
print(dir(time))

print(type(math))       #math는 모듈
print(type(math.cos))   #math라는 모듈이 제공하는 코사인 함수

