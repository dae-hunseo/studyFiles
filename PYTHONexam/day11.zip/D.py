import datetime
print(__name__ +"모듈 : "+ str(datetime.datetime.now())) #직접 수행되면 name은 main이고, A.py에서처럼 다른 파일에서 import되어 쓰이면 name은 파일 이름
