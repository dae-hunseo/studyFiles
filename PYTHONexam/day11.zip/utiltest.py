import util

print("1inch =", util.INCH)
print("~10 =", util.calcsum(10))

print(__name__)

