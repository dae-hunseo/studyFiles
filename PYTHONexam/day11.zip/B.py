import datetime
print(__name__ +"모듈 : "+ str(datetime.datetime.now()))  #파이썬 소스가 파이썬 인터프리터에 의해서 직접적으로 수행되면 name은 main이고, 다른 소스파일에서 import 되어 사용되면 name은 파일 이름이 된다.