# 코드 9-9 : 두 개의 리스트와 == 연산
## "으뜸 파이썬", p. 544

list_a = [10, 20, 30]
list_b = [10, 20, 30]

if list_a == list_b:
    print('list_a == list_b')
else:
    print('list_a != list_b')
