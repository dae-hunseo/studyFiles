# 코드 9-1 : Cat 클래스 정의와 객체 생성 문법
## "으뜸 파이썬", p. 530

class Cat:    # Cat 클래스의 정의
    pass

nabi = Cat()  # Cat 인스턴스 생성
print(nabi)
