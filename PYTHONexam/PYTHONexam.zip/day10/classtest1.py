print("파이썬 인터프리터가 직접 실행시키는 파이썬 소스의 모듈명 :", __name__) #__main__ 출력

class Student :
    pass

st1 = Student()
st2 = Student()
st3 = Student()

print(type(st1), st1) #2번째 매개변수는 메모리 어디에 위치한지 값 출력
print(type(st2), st2)
print(type(st3), st3)


