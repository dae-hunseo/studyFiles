# 코드 9-2 : Cat 클래스 정의와 meow() 메소드
## "으뜸 파이썬", p. 531

class Cat:
    def meow(self):
        print('야옹 야옹~~~')

nabi = Cat()
nabi.meow()
