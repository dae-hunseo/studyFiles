import math
import time

print(dir(math))
print(dir(time))

print(type(math))
print(type(math.cos))

