import util1

print("1inch =", util1.INCH)
print("~10 =", util1.calcsum(10))

