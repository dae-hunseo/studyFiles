import time
import datetime
print(__name__ +"모듈 : "+ str(datetime.datetime.now()))
time.sleep(3)
import B
time.sleep(3)
import C
time.sleep(3)
import D
time.sleep(3)
print(__name__ +"모듈 : "+ str(datetime.datetime.now()))

