import sys
print(sys.path)
print(type(sys.path))