import util2

print("1inch =", util2.INCH)
print("~10 =", util2.calcsum(10))