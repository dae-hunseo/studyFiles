import datetime
print(__name__ +"모듈 : "+ str(datetime.datetime.now()))
