num1 = 10
num2 = 25
num3 = 34
sum = num1 + num2 + num3
avg = sum / 3
print("합은 ", sum, "이고 평균은 ", avg, "입니다." , sep='') #pdf 63pg 참고