num1 = int(input('num1 입력: '))
num2 = int(input('num2 입력: '))
print(num1,'+',num2,'=',num1+num2)
print(num1,'*',num2,'=',num1*num2)