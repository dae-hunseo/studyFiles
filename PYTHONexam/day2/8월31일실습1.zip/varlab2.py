name1="서"
name2="대"
name3="훈"
print(name1 + name2 + name3) # == print(name1, name2, name3, sep='')
print(name1, name2, name3, sep = '@')
print(name1, name2, name3, sep = "---")