num = int(input('num 입력: '))
if num > 10:
    print("OK")