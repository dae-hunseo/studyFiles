color_name = input("색상 이름 입력: ")
if color_name == "red":
    print("#ff0000")
else:
    print("#000000")