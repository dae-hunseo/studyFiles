for _ in range(5):
    print('@')