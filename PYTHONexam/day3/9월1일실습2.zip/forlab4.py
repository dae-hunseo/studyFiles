for i in range(9, 3, -1):
    if i % 2 == 0:
        print(i,": 짝수", sep='')
    else:
        print(i,": 홀수", sep='')