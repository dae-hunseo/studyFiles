import random

ran_num = random.randint(5,10)
i = 1
# print("ran_num: ", ran_num)
while i<=ran_num:
    print(i,"->",i*i)
    i += 1