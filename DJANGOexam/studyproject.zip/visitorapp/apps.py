from django.apps import AppConfig


class ForthappConfig(AppConfig):
    name = 'visitorapp'
