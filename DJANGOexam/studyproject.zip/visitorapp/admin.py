from django.contrib import admin
from .models import Visitor

admin.site.register(Visitor)

