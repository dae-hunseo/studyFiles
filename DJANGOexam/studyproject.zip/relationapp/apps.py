from django.apps import AppConfig


class RelationappConfig(AppConfig):
    name = 'relationapp'
